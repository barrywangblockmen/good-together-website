#!/usr/bin/env python3
"""GT投研 報告輸出工具：HTML → A4 PDF ＋ 每頁截圖（供視覺檢查）。
用法: python3 render_pdf.py <input.html> <output.pdf>
"""
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

html = Path(sys.argv[1]).resolve()
pdf = Path(sys.argv[2]).resolve()

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 820, "height": 1200})
    pg.goto(html.as_uri())
    pg.wait_for_timeout(400)
    pg.pdf(path=str(pdf), format="A4", print_background=True,
           margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})
    for i, el in enumerate(pg.query_selector_all(".page"), 1):
        el.screenshot(path=str(pdf.with_name(f"qa_page{i}.png")))
    b.close()
print(f"OK: {pdf}")
